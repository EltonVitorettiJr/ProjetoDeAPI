import os
from flask import Flask, request, jsonify, render_template, redirect
from flask_cors import CORS

# Definir explicitamente a pasta de templates
app = Flask(__name__, template_folder=os.path.join(os.getcwd(), 'templates'))
CORS(app)

# Dados simulados
cursos = []
alunos = []
curso_id_counter = 1
aluno_id_counter = 1
@app.route('/')
def home():
    return render_template('inicio.html')  # ou 'alunos.html'

if __name__ == '__main__':
    app.run(debug=True)
    
@app.route('/')
def home():
    return render_template('inicio.html', cursos=cursos)

@app.route('/cursos', methods=['POST'])
def adicionar_curso():
    global curso_id_counter
    nome = request.form['nome']
    descricao = request.form['descricao']
    novo_curso = {"id": curso_id_counter, "nome": nome, "descricao": descricao}
    cursos.append(novo_curso)
    curso_id_counter += 1
    return redirect('/')

@app.route('/alunos', methods=['POST'])
def adicionar_aluno():
    global aluno_id_counter
    nome = request.form['nome']
    idade = request.form['idade']
    curso_id = int(request.form['curso_id'])
    
    curso = next((c for c in cursos if c["id"] == curso_id), None)
    if not curso:
        return jsonify({"error": "Curso não encontrado"}), 404
    
    novo_aluno = {"id": aluno_id_counter, "nome": nome, "idade": idade, "curso": curso["nome"]}
    alunos.append(novo_aluno)
    aluno_id_counter += 1
    return redirect('/')

@app.route('/alunos', methods=['GET'])
def listar_alunos():
    return render_template('alunos.html', alunos=alunos)

if __name__ == '__main__':
    app.run(debug=True)
